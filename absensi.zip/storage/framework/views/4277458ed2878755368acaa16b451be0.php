<?php $__env->startPush('header'); ?>
    <div class="logo-wrapper"><a href="https://sixghakreasi.com/demos/attd_mobile/"><img src="assets/img/tms.png"
                alt="" width="40" height="40"></a></div>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="pt-3">
            <!-- Hero Slides-->
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="<?php echo e(asset('assets/img/slide-1.jpeg')); ?>" class="d-block w-full h-full" alt="..."
                            height="300" style="border-radius:10px;">
                    </div>
                    <div class="carousel-item">
                        <img src="<?php echo e(asset('assets/img/slide-2.png')); ?>" class="d-block w-full h-full" alt="..."
                            height="300" style="border-radius:10px;">
                    </div>
                    <div class="carousel-item">
                        <img src="<?php echo e(asset('assets/img/slide-3.jpeg')); ?>" class="d-block w-full h-full" alt="..."
                            height="300" style="border-radius:10px;">
                    </div>
                </div>
                <button class="carousel-control-prev"
                    style="background: transparent; outline: none; border:none; color:red;" type="button"
                    data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next"
                    style="background: transparent; outline: none; border:none; color:red;" type="button"
                    data-bs-target="#carouselExampleControls" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </div>
    <!-- Product Catagories-->
    <div class="product-catagories-wrapper py-3">
        <div class="container">
            <div class="section-heading">
                <h6>Menu</h6>
            </div>
            <div class="product-catagory-wrap">
                <div class="row g-3">
                    <!-- Single Catagory Card-->
                    <div class="col-4">
                        <div class="card catagory-card">
                            <div class="card-body"><a class="text-danger" href="<?php echo e(route('attendance')); ?>"><i
                                        class="lni lni-map-marker"></i><span>Absensi</span></a></div>
                        </div>
                    </div>
                    <!-- Single Catagory Card-->
                    <div class="col-4">
                        <div class="card catagory-card">
                            <div class="card-body"><a href="<?php echo e(route('leave')); ?>"><svg xmlns="http://www.w3.org/2000/svg"
                                        width="28" height="28" fill="currentColor" class="bi bi-cup mb-2"
                                        viewBox="0 0 16 16">
                                        <path fill-rule="evenodd"
                                            d="M1 2a1 1 0 0 1 1-1h11a1 1 0 0 1 1 1v1h.5A1.5 1.5 0 0 1 16 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-.55a2.5 2.5 0 0 1-2.45 2h-8A2.5 2.5 0 0 1 1 12.5V2zm13 10h.5a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.5-.5H14v8zM13 2H2v10.5A1.5 1.5 0 0 0 3.5 14h8a1.5 1.5 0 0 0 1.5-1.5V2z">
                                        </path>
                                    </svg><span>Cuti</span></a></div>
                        </div>
                    </div>
                    <!-- Single Catagory Card-->
                    <div class="col-4">
                        <div class="card catagory-card">
                            <div class="card-body"><a class="text-warning"
                                    href="<?php echo e(route('permit')); ?>"><i
                                        class="lni lni-information"></i><span>Izin</span></a></div>
                        </div>
                    </div>
                    <!-- Single Catagory Card-->
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\absensi\resources\views/home.blade.php ENDPATH**/ ?>