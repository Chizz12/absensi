

<?php $__env->startPush('header'); ?>
    <div class="back-button"><a href="<?php echo e(route('attendance')); ?>">
            <svg class="bi bi-arrow-left" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                viewBox="0 0 16 16">
                <path fill-rule="evenodd"
                    d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z">
                </path>
            </svg></a></div>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="product-catagories-wrapper py-3">
            <div class="container">
                <div class="section-heading">
                    <h6>Pilih Shift</h6>
                </div>
                <div class="product-catagory-wrap">
                    <div class="row">
                        <!-- Single Catagory Card-->
                        <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 pb-2">
                                <div class="card shadow-sm border rounded-lg">
                                    <div class="card-body">
                                        <h5 class="card-title mb-2 text-capitalize"><i class="bi bi-activity fw-bold fs-5 text-success"></i> <?php echo e($item->nama); ?></h5>
                                        <p class="card-text">Maksimal Toleransi
                                            <?php echo e(\Carbon\Carbon::parse($item->waktu)->format('H:i')); ?> WIB</p>
                                        <div class="dropdown">
                                            <a class="btn btn-danger dropdown-toggle w-100" href="#" role="button"
                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                Absen Sekarang
                                            </a>

                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item text-success"
                                                        href="<?php echo e(route('add-attendance', [$item->id_shift, 'in'])); ?>"><i class="bi bi-box-arrow-right text-success me-2"></i>Masuk</a>
                                                </li>
                                                <li><a class="dropdown-item text-warning"
                                                        href="<?php echo e(route('add-attendance', [$item->id_shift, 'out'])); ?>"><i class="bi bi-box-arrow-left text-danger me-2"></i>Keluar</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\absensi\resources\views/pages/shift.blade.php ENDPATH**/ ?>